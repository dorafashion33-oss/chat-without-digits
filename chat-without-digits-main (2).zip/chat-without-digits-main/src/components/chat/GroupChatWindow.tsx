import { Send, ArrowLeft, Users, UserPlus, Trash2, Settings, Phone, Video, Paperclip, X, FileText, Forward } from "lucide-react";
import { useState, useRef, useEffect, useCallback } from "react";
import type { Group, GroupMessage, GroupMember } from "@/hooks/useGroups";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import MessageContent from "./MessageContent";
import MessageForwardDialog, { type ForwardRecipient } from "./MessageForwardDialog";

interface GroupChatWindowProps {
  group: Group;
  currentUserId: string;
  onSendMessage: (groupId: string, text: string) => void;
  fetchMessages: (groupId: string) => Promise<GroupMessage[]>;
  fetchMembers: (groupId: string) => Promise<GroupMember[]>;
  onAddMember?: (groupId: string, userId: string) => void;
  onRemoveMember?: (groupId: string, userId: string) => void;
  onDeleteGroup?: (groupId: string) => void;
  onStartCall?: (userId: string, type: "voice" | "video") => void;
  onStartGroupCall?: (type: "voice" | "video") => void;
  onBack?: () => void;
  profiles: ForwardRecipient[];
  onDeleteMessage?: (messageId: string) => void;
}

const GroupChatWindow = ({
  group, currentUserId, onSendMessage, fetchMessages, fetchMembers,
  onAddMember, onRemoveMember, onDeleteGroup, onStartCall, onStartGroupCall, onBack, profiles, onDeleteMessage,
}: GroupChatWindowProps) => {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<GroupMessage[]>([]);
  const [members, setMembers] = useState<GroupMember[]>([]);
  const [showInfo, setShowInfo] = useState(false);
  const [attachedFile, setAttachedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [forwardMessage, setForwardMessage] = useState<GroupMessage | null>(null);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const longPressRef = useRef<ReturnType<typeof setTimeout>>();
  const isAdmin = group.created_by === currentUserId;

  const loadMessages = useCallback(async () => {
    const msgs = await fetchMessages(group.id);
    setMessages(msgs);
  }, [group.id, fetchMessages]);

  const loadMembers = useCallback(async () => {
    const mems = await fetchMembers(group.id);
    setMembers(mems);
  }, [group.id, fetchMembers]);

  useEffect(() => {
    loadMessages();
    loadMembers();

    const channel = supabase
      .channel(`group-${group.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "group_messages", filter: `group_id=eq.${group.id}` }, () => {
        loadMessages();
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [group.id, loadMessages, loadMembers]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text && !attachedFile) return;
    let msgText = text;

    if (attachedFile) {
      setUploading(true);
      const currentFile = attachedFile;
      setAttachedFile(null);
      setFilePreview(null);
      const safeName = currentFile.name.replace(/[^a-zA-Z0-9._-]+/g, "_");
      const path = `${currentUserId}/groups/${group.id}/${Date.now()}_${safeName}`;
      const { error: upErr } = await supabase.storage
        .from("chat-media")
        .upload(path, currentFile, { cacheControl: "3600", upsert: false, contentType: currentFile.type || undefined });
      if (upErr) {
        toast.error("Upload failed: " + upErr.message);
        setUploading(false);
        return;
      }
      const { data: urlData } = supabase.storage.from("chat-media").getPublicUrl(path);
      const url = urlData.publicUrl;
      if (currentFile.type.startsWith("image/")) msgText = `[img]${url}[/img]${text ? `\n${text}` : ""}`;
      else if (currentFile.type.startsWith("video/")) msgText = `[video]${url}[/video]${text ? `\n${text}` : ""}`;
      else msgText = `[file:${currentFile.name}]${url}[/file]${text ? `\n${text}` : ""}`;
      setUploading(false);
    }

    setInput("");
    if (msgText) onSendMessage(group.id, msgText);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 50 * 1024 * 1024) { toast.error("File too large. Max 50MB."); return; }
    setAttachedFile(file);
    if (file.type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onload = (ev) => setFilePreview(ev.target?.result as string);
      reader.readAsDataURL(file);
    } else {
      setFilePreview(null);
    }
    e.target.value = "";
  };

  const colors = ["bg-blue-500", "bg-purple-500", "bg-pink-500", "bg-violet-500", "bg-indigo-500", "bg-fuchsia-500", "bg-cyan-500", "bg-blue-600"];

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 border-b bg-chat-header px-4 py-3">
        {onBack && (
          <button onClick={onBack} className="rounded-full p-1 hover:bg-accent"><ArrowLeft className="h-5 w-5 text-foreground" /></button>
        )}
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
          <Users className="h-5 w-5" />
        </div>
        <div className="flex-1 min-w-0">
          <h2 className="text-sm font-semibold text-foreground truncate">{group.name}</h2>
          <p className="text-xs text-muted-foreground">{members.length} members</p>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => onStartGroupCall?.("voice")} className="rounded-full p-2 hover:bg-accent" title="Group voice call">
            <Phone className="h-4 w-4 text-muted-foreground" />
          </button>
          <button onClick={() => onStartGroupCall?.("video")} className="rounded-full p-2 hover:bg-accent" title="Group video call">
            <Video className="h-4 w-4 text-muted-foreground" />
          </button>
          <button onClick={() => setShowInfo(!showInfo)} className="rounded-full p-2 hover:bg-accent">
            <Settings className="h-4 w-4 text-muted-foreground" />
          </button>
        </div>
      </div>

      {showInfo ? (
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <div className="rounded-xl bg-accent/50 p-4">
            <h3 className="text-sm font-semibold text-foreground mb-1">{group.name}</h3>
            {group.description && <p className="text-xs text-muted-foreground">{group.description}</p>}
          </div>
          <div>
            <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-2 px-1">Members ({members.length})</p>
            {members.map((m) => {
              const name = m.profile?.display_name || m.profile?.username || "Unknown";
              const ci = (m.profile?.username || "U").charCodeAt(0) % colors.length;
              return (
                <div key={m.id} className="flex items-center gap-3 rounded-xl px-3 py-2 hover:bg-accent/50">
                  {m.profile?.avatar_url ? (
                    <img src={m.profile.avatar_url} alt={name} className="h-10 w-10 rounded-full object-cover" />
                  ) : (
                    <div className={`flex h-10 w-10 items-center justify-center rounded-full ${colors[ci]} text-xs font-semibold text-white`}>
                      {name[0]?.toUpperCase()}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{name}</p>
                    <p className="text-xs text-muted-foreground">{m.role === "admin" ? "Admin" : "Member"}</p>
                  </div>
                  {isAdmin && m.user_id !== currentUserId && onRemoveMember && (
                    <button onClick={() => { onRemoveMember(group.id, m.user_id); loadMembers(); }} className="rounded p-1 hover:bg-destructive/10">
                      <Trash2 className="h-3.5 w-3.5 text-destructive" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
          {isAdmin && onDeleteGroup && (
            <button onClick={() => onDeleteGroup(group.id)} className="flex w-full items-center justify-center gap-2 rounded-xl bg-destructive/10 p-3 text-sm font-medium text-destructive hover:bg-destructive/20 transition-colors">
              <Trash2 className="h-4 w-4" /> Delete Group
            </button>
          )}
          <button onClick={() => setShowInfo(false)} className="flex w-full items-center justify-center rounded-xl bg-accent p-3 text-sm font-medium text-foreground hover:bg-accent/80">
            Back to Chat
          </button>
        </div>
      ) : (
        <>
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 scrollbar-thin" style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, hsl(var(--border) / 0.3) 1px, transparent 0)`,
            backgroundSize: "24px 24px",
          }}>
            <div className="mx-auto max-w-3xl space-y-1">
              {messages.length === 0 && (
                <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
                  <Users className="h-10 w-10 mb-2 opacity-30" />
                  <p className="text-sm">No messages yet. Say hello! 👋</p>
                </div>
              )}
              {messages.map((msg, i) => {
                const isOwn = msg.sender_id === currentUserId;
                const senderName = msg.profile?.display_name || msg.profile?.username || "Unknown";
                const showSender = !isOwn && (i === 0 || messages[i - 1].sender_id !== msg.sender_id);
                const time = new Date(msg.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
                return (
                  <div key={msg.id} className={`flex ${isOwn ? "justify-end" : "justify-start"} ${showSender ? "mt-3" : "mt-0.5"}`}>
                    <div
                      className="group/message relative max-w-[85%] sm:max-w-[75%]"
                      onContextMenu={(event) => { event.preventDefault(); setActiveMenuId(activeMenuId === msg.id ? null : msg.id); }}
                      onTouchStart={() => { longPressRef.current = setTimeout(() => setActiveMenuId(msg.id), 500); }}
                      onTouchEnd={() => { if (longPressRef.current) clearTimeout(longPressRef.current); }}
                    >
                    <div className={`rounded-2xl px-3.5 py-2 ${isOwn ? "bg-chat-bubble-own text-chat-bubble-own-foreground rounded-br-md" : "bg-chat-bubble-other text-chat-bubble-other-foreground rounded-bl-md"}`}>
                      {showSender && <p className="text-xs font-semibold text-primary mb-0.5">{senderName}</p>}
                      {msg.text.startsWith("[forwarded]") && <p className="mb-1 flex items-center gap-1 text-[10px] opacity-60"><Forward className="h-3 w-3" /> Forwarded</p>}
                      <MessageContent text={msg.text.startsWith("[forwarded]") ? msg.text.slice("[forwarded]".length) : msg.text} />
                      <p className="text-[10px] opacity-60 text-right mt-0.5">{time}</p>
                    </div>
                    <div className={`absolute ${isOwn ? "right-0" : "left-0"} -top-9 z-20 ${activeMenuId === msg.id ? "flex" : "hidden group-hover/message:flex"} items-center gap-1 rounded-lg border bg-popover p-1 shadow-md`}>
                      <button onClick={() => { setForwardMessage(msg); setActiveMenuId(null); }} aria-label="Forward message" title="Forward" className="rounded p-1.5 hover:bg-accent"><Forward className="h-4 w-4 text-muted-foreground" /></button>
                      {isOwn && onDeleteMessage && <button onClick={() => { onDeleteMessage(msg.id); setMessages((previous) => previous.filter((item) => item.id !== msg.id)); setActiveMenuId(null); }} aria-label="Delete message" title="Delete" className="rounded p-1.5 hover:bg-destructive/10"><Trash2 className="h-4 w-4 text-destructive" /></button>}
                    </div>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>
      <MessageForwardDialog
        open={Boolean(forwardMessage)}
        profiles={profiles.filter((profile) => profile.user_id !== currentUserId)}
        messageText={forwardMessage?.text || ""}
        onOpenChange={(open) => { if (!open) setForwardMessage(null); }}
        onForward={(receiverId, text) => onSendMessage(receiverId, `[forwarded]${text}`)}
      />
          </div>

          {/* Attachment preview */}
          {attachedFile && (
            <div className="border-t bg-chat-header px-4 py-2">
              <div className="mx-auto max-w-3xl flex items-center gap-3">
                {filePreview ? (
                  <img src={filePreview} alt="preview" className="h-14 w-14 rounded-xl object-cover" />
                ) : (
                  <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-accent">
                    <FileText className="h-5 w-5 text-muted-foreground" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{attachedFile.name}</p>
                  <p className="text-xs text-muted-foreground">{(attachedFile.size / 1024).toFixed(1)} KB</p>
                </div>
                <button onClick={() => { setAttachedFile(null); setFilePreview(null); }} className="rounded-full p-1.5 hover:bg-accent transition-colors">
                  <X className="h-4 w-4 text-muted-foreground" />
                </button>
              </div>
            </div>
          )}

          {/* Input */}
          <div className="border-t bg-chat-header px-4 py-3">
            <div className="mx-auto flex max-w-3xl items-center gap-2">
              <button onClick={() => fileInputRef.current?.click()} className="rounded-full p-2 hover:bg-accent transition-colors" title="Attach file" disabled={uploading}>
                <Paperclip className="h-5 w-5 text-muted-foreground" />
              </button>
              <input ref={fileInputRef} type="file" className="hidden" onChange={handleFileChange} accept="image/*,video/*,audio/*,.gif,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.zip,.rar,.7z,.json,.apk" />
              <div className="flex flex-1 items-center rounded-2xl bg-chat-input-bg px-4 py-2.5">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSend()}
                  placeholder={uploading ? "Uploading..." : "Type a group message..."}
                  className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
                  disabled={uploading}
                />
              </div>
              {(input.trim() || attachedFile) && (
                <button onClick={handleSend} disabled={uploading} className="flex h-10 w-10 items-center justify-center rounded-full gradient-brand text-white hover:opacity-90 disabled:opacity-60">
                  <Send className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default GroupChatWindow;
